angular.module('starter.controllers', [])

.controller('homeCtrl', function($scope, $state,$stateParams) {
  $scope.startQuiz = function(){
    $state.go("imageQuestion", {
      "imageQuestionAnswer": null,
      'textQuestionAnswer': null
    })
  }
})
  .controller('imageQCtrl', function($scope, $state,$stateParams) {
    console.log($stateParams)
    $scope.answers = ["Male","Female","Can't tell"];

    $scope.imageClick = function($answer){
      $state.go("textQuestion",{
        "imageQuestionAnswer":$answer,
        "textQuestionAnswer": null
      })
    }
  })
  .controller('textQCtrl', function($scope,$state,$stateParams) {
console.log($stateParams)
    $scope.textClick = function($textAnswer){
      $state.go("result",{
        "imageQuestionAnswer":$stateParams.imageQuestionAnswer,
        "textQuestionAnswer": $textAnswer
    })

} })
  .controller('resultCtrl', function($scope,$state,$stateParams) {
    console.log($stateParams)
    var answer1 = $stateParams.imageQuestionAnswer;
    var answer2 = $stateParams.textQuestionAnswer;
    var correctNum = 0;


    if(answer1 == "Female") correctNum = correctNum+1;
    if(answer2 == "haha") correctNum = correctNum +1;
    $scope.correctNum = correctNum;

    $scope.resultClick = function(){
      $state.go("home",{
        "imageQuestionAnswer":null,
        "textQuestionAnswer": null
      })
    }
  })




/*
.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});*/
